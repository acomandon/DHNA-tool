Affirmatively Furthering Fair Housing Public Used Datafiles
2024 December Release
 
 
-------------------------------------
VERSION
-------------------------------------
AFFHT0007
 
 
-------------------------------------
CONTENTS
-------------------------------------
The package contains the following files:
                  
* AFFH_blockgroup_AFFHT0007_December2024.csv 
          - A blockgroup level file of demographic and socioeconomic variables as well as school proficiency and job proximity indices used in the AFFH-T. 
          - Many of these variables are aggregated up to the tract, jurisdiction, region, PHA and etc., for display in the AFFH-T. 
          - The aggregation of demographic variables often use the blockgroup crosswalks laid out in "AFFH_Public_Use_Crosswalk_AFFHT0007_December2024.csv".
          - The aggregation of indices use methods laid out in "AFFHT0007 Data Documentation.docx"
  
* AFFH_tract_AFFHT0007_December2024.csv
          - A tract level file of all the demographic, socioeconomic and housing characteristics variables as well as a series of Opportunity Indices used in the AFFH-T. 
          - Many of these variables are aggregated up to the jurisdiction, region, PHA and etc., for display in the AFFH-T. 
          - The aggregation of demographic, socioeconomic and housing characteristics variables often use the tract crosswalks laid out in AFFH_Public_Use_Crosswalk_AFFHT0007_December2024.csv.
          - The aggregation of indices use methods laid out in "AFFHT0007 Data Documentation.docx"
 
* AFFH_county_AFFHT0007_December2024.csv
          - A county level file of all the demographic, socioeconomic and housing characteristics variables as well as a series of Opportunity Indices used in the AFFH-T. 
          - A set of adjusted school indices and alternative job indices are provided, which are not used in the AFFH-T. 
 
* AFFH_jurisdiction_AFFHT0007_December2024.csv
          - A jurisdiction level file of all the demographic, socioeconomic and housing characteristics variables as well as a series of Opportunity Indices used in the AFFH-T. 
          - A set of adjusted school indices and alternative job indices are provided, which are not used in the AFFH-T.
          - A jurisdiction is any HUD local government that is subject to AFFH requirements, including Community Development Block Grant (GRANTEE_CATEGORY = '1'), HOME Investment Partnerships Program (GRANTEE_CATEGORY = '2') and Different Boundary (GRANTEE_CATEGORY = '3'). The different boundary category was created to hold the five HOME grantees that have different jurisdictional boundaries than the CDBG grant for the same city. The differences between the HOME and CDBG jurisdictional boundaries [MOU1] is often due to Joint agreements for CDBG funds, which allow an Urban County to manage and administer a Metropolitan City’s CDBG grant in addition to the County’s CDBG grant. For example, the Los Angeles County CDBG jurisdiction includes Torrance, CA as they have a joint CDBG agreement. But the Los Angeles County HOME jurisdiction excludes Torrance, CA. 
 
* AFFH_region_AFFHT0007_December2024.csv
          - A Region level file of all the demographic, socioeconomic and housing characteristics variables as well as a series of Opportunity Indices used in the AFFH-T. 
          - A set of adjusted school indices and alternative job indices are provided, which are not used in the AFFH-T.
          - A Region is the comparison area to a jurisdiction or PHA that is subject to AFFH requirements. A region is either 1) a Core-based Statistical Area (CBSA), 2) the non-CBSA portion of a state, or 3) a Customized Region Area. Customized Regions are created for HOME Investment Partnerships Program (Home-Consortia Grantees) that are not within one CBSA. To be specific, if at least 90% of a HOME Consortia’s population falls within one CBSA, then the HOME Consortia’s region is the CBSA. If that is not the case, then a Customized Region is created, which consists of all counties interacting with the grantee boundary.
 
* AFFH_PHA_JURIS_AFFHT0007_December2024.csv
          - A PHA level file of all the demographic, socioeconomic and housing characteristics variables as well as a series of Opportunity Indices used in the AFFH-T. 
          - A set of adjusted school indices and alternative job indices are provided, which are not used in the AFFH-T.
          - A PHA is any Public Housing Agency (PHA) Service Area that is subject to AFFH requirements (GRANTEE_CATEGORY = '4').
 
* AFFH_ENTL_NONENTL_AFFHT0007_December2024.csv
          - A state Entitlement and Non-Entitlement level file of all the demographic, socioeconomic and housing characteristics variables as well as a series of Opportunity Indices used in the AFFH-T. 
          - A set of adjusted school indices and alternative job indices are provided, which are not used in the AFFH-T.
          - The state Non-entitlement areas are cities with populations of less than 50,000 (except cities that are designated principal cities of Metropolitan Statistical Areas), and counties with populations of less than 200,000 (GRANTEE_CATEGORY = '7').
          - The state entitlement areas are unit of general Local Government that has been designated by HUD to receive home allocations (GRANTEE_CATEGORY = '6').
 
* AFFH_state_AFFHT0007_December2024.csv
          - A state level file of all the demographic, socioeconomic and housing characteristics variables as well as series of Opportunity Indices used in the AFFH-T. 
          - A set of adjusted school indices and alternative job indices are provided, which are not used in the AFFH-T.
 
* HOUSING_LIHTC_AFFHT0007_December2024.csv
          - A tract level file of Low-Income Housing Tax Credit (LIHTC) program attributes.
          - Some of these variables are aggregated up to state, for public use. 
          - The aggregation of variables often use the tract crosswalks laid out in AFFH_Public_Use_Crosswalk_AFFHT0007_December2024.csv.
 
* HOUSING_project_AFFHT0007_December2024.csv
          - A project level file of assisted housing program attributes, including Public Housing (program = '2'), Section 8 Project-based Rental Assistance (program = '3') and other assisted housing multifamily properties (program = '4').
          - Many of these variables are aggregated up to the jurisdiction, region, PHA and etc., for display in the AFFH-T. 
 
* HOUSING_tract_AFFHT0007_December2024.csv
          - A tract [MOU2] [MOU3] level file of assisted housing program attributes, including Public Housing (program = '2'), Section 8 tenant-based Housing Choice Voucher (program = '3'), Section 8 Project-based Rental Assistance (program = '4') and other assisted housing multifamily properties (program = '5').
          - Many of these variables are aggregated up to the jurisdiction, region, PHA and etc., for display in the AFFH-T. 
          - The aggregation of variables often use the tract crosswalks laid out in AFFH_Public_Use_Crosswalk_AFFHT0007_December2024.csv.
 
* AFFH_Public_Use_Data_Dictionaries_AFFHT0007_December2024.xlsx
          - A data dictionary for all the datasets above. Each tab contains the names and definitions of the columns for each of the above datasets.
 
* AFFH_Public_Use_Crosswalk_AFFHT0007_December2024.xlsx
          - A crosswalk file with weights and formulas that lays out how block group and census tract attributes were aggregated up to the jurisdiction, region, and other geography levels for use in the AFFH-T. 
          - Many of the crosswalks were used for internal data processing tasks and may not be directly useful for data users.
          - HUD jurisdiction boundaries are constructed from one or more Census summary level 070 geographies appended together. The exact list of Summary level 070 geographies corresponding to a jurisdiction can be found in the “Jurisdiction_sum070” tab. Note that the Census has discontinued publishing summary level 070 geography and data files as of 2015, and that HUD’s jurisdiction boundaries will likely be very different from the official Census boundaries for a county or city.
          - To construct these crosswalks and weights, a combination of the following data were used: Census 2020 block level population counts, the Longitudinal Employer-Household Dynamics (LEHD) Version 8 2020 block level geographic crosswalk, and internal HUD administrative data.